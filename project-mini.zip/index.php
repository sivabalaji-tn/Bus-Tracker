<?php
session_start();

// Auto-redirect if already logged in
if (isset($_SESSION['admin_logged_in'])) {
  if ($_SESSION['admin_role'] === 'Admin') {
    header("Location: admin-dashboard.php");
  } elseif ($_SESSION['admin_role'] === 'Bus Driver') {
    header("Location: driver-dashboard.php");
  }
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Bus Tracker Portal</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <link href="admin-styles/admin.css" rel="stylesheet">
</head>
<body class="admin-login-bg">

<div class="container d-flex justify-content-center align-items-center vh-100">
  <div class="card shadow-lg p-4" style="max-width: 400px; width: 100%;">
    <div class="text-center mb-4">
      <i class="bi bi-bus-front-fill text-success display-4"></i>
      <h3 class="text-success mt-2">Bus Tracker</h3>
      <p class="text-muted">Select your login type</p>
    </div>

    <div class="d-grid gap-3">
        <a href="track.php" class="btn btn-outline-success">
      <i class="bi bi-geo-alt-fill me-1"></i> Track Buses
      </a>
      <a href="admin/admin-login.php" class="btn btn-success">
        <i class="bi bi-person-badge-fill me-1"></i> Admin Login
      </a>
      <a href="admin/driver-login.php" class="btn btn-outline-success">
        <i class="bi bi-truck-front-fill me-1"></i> Driver Login
      </a>
    </div>
  </div>
</div>

</body>
</html>
