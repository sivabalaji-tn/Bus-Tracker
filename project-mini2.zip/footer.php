<footer class="bg-dark text-white py-3">
  <div class="container text-center">
    <p class="mb-1">© 2025 Siva Balaji – IT Student | Pre-Final Year</p>
    <p class="small text-muted">All rights reserved.</p>
  </div>
</footer>
